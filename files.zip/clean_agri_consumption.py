import pandas as pd, numpy as np, glob, re

SRC = glob.glob('/mnt/user-data/uploads/*.csv')[0]

# 1. Read: skip the title row, keep everything as text so nothing is silently coerced
raw = pd.read_csv(SRC, skiprows=1, dtype=str, keep_default_na=False, encoding='utf-8-sig')
raw.columns = [c.strip() for c in raw.columns]

# 2. Hierarchy: leading dots in Geolocation encode the level (0 = country, 2 = region, 4 = province/district)
raw['geo_level'] = raw['Geolocation'].str.extract(r'^(\.*)')[0].str.len().map({0: 'country', 2: 'region', 4: 'province_or_district'})
raw['classification'] = raw['Classification of Barangays'].str.lstrip('. ').str.strip().str.title()
raw['location'] = raw['Geolocation'].str.lstrip('. ').str.strip()

# carry the parent region down onto province/district rows (reset per classification block)
raw['region'] = np.where(raw['geo_level'] == 'region', raw['location'], np.nan)
raw['region'] = raw.groupby('classification')['region'].ffill()
raw.loc[raw['geo_level'] == 'country', 'region'] = np.nan
raw['province_or_district'] = np.where(raw['geo_level'] == 'province_or_district', raw['location'], np.nan)

id_cols = ['classification', 'geo_level', 'location', 'region', 'province_or_district']
value_cols = [c for c in raw.columns if re.match(r'^(\d{4}(-\d{4})?) ', c)]

# 3. Wide -> long: split "1999-2000 Rice" into period + commodity
long = raw[id_cols + value_cols].melt(id_vars=id_cols, var_name='col', value_name='raw_value')
long[['period', 'commodity']] = long['col'].str.extract(r'^(\d{4}(?:-\d{4})?) (.+)$')
long = long.drop(columns='col')

# 4. Missing markers: "." and ".." -> NaN (original marker kept for reference); everything else numeric
long['missing_marker'] = long['raw_value'].where(long['raw_value'].isin(['.', '..']))
long['per_capita_consumption'] = pd.to_numeric(long['raw_value'].where(~long['raw_value'].isin(['.', '..'])), errors='raise')
long = long.drop(columns='raw_value')

# 5. Numeric period helpers for modelling
yrs = long['period'].str.extract(r'^(\d{4})(?:-(\d{4}))?$').astype(float)
long['year_start'] = yrs[0].astype(int)
long['year_end'] = yrs[1].fillna(yrs[0]).astype(int)
long['year_mid'] = (long['year_start'] + long['year_end']) / 2

# 6. Sanity checks
assert not long.duplicated(id_cols + ['period', 'commodity']).any(), 'duplicate keys'
assert (long['per_capita_consumption'].dropna() >= 0).all()

# 7. Outputs
order = id_cols + ['period', 'year_start', 'year_end', 'year_mid', 'commodity', 'per_capita_consumption', 'missing_marker']
long = long[order]
tidy = long.dropna(subset=['per_capita_consumption']).drop(columns='missing_marker')
tidy.to_csv('/mnt/user-data/outputs/agri_consumption_clean_long.csv', index=False)

keys = id_cols + ['period', 'year_start', 'year_end', 'year_mid']
wide = (long.assign(**{c: long[c].astype(object).where(long[c].notna(), '__NA__') for c in ['region', 'province_or_district']})
            .set_index(keys + ['commodity'])['per_capita_consumption'].unstack('commodity').reset_index())
for c in ['region', 'province_or_district']:
    wide[c] = wide[c].replace('__NA__', np.nan)
wide.columns.name = None
val_cols = [c for c in wide.columns if c not in keys]
wide = wide.dropna(subset=val_cols, how='all')
wide.to_csv('/mnt/user-data/outputs/agri_consumption_clean_wide.csv', index=False)

print('raw rows', len(raw), '| raw value cells', len(raw) * len(value_cols))
print('long rows (all cells)', len(long), '| tidy rows (non-missing)', len(tidy))
print('wide rows', len(wide), 'cols', wide.shape[1])
print(long['missing_marker'].value_counts(dropna=False).to_string())
print(tidy.groupby('period').size().to_string())
print(tidy['per_capita_consumption'].describe().round(3).to_string())
